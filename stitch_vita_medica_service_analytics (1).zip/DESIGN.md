# Design System Document: The Clinical Editorial

## 1. Overview & Creative North Star
**The Creative North Star: "Precision Vitality"**

Traditional medical dashboards feel sterile, cold, and rigid. This design system rejects the "spreadsheet" aesthetic in favor of a **High-End Editorial** experience. We treat patient data with the same reverence as a luxury magazine layout—utilizing massive, authoritative typography, generous white space, and an "Atmospheric Layering" technique.

The goal is to break the "template" look. We achieve this through:
- **Intentional Asymmetry:** Important metrics are not just "boxes"; they are typographic statements.
- **Tonal Depth:** Replacing harsh lines with soft, overlapping planes of color.
- **Bespoke Charting:** Data isn't just displayed; it's integrated into the UI as a primary visual element.

---

## 2. Colors: The Fresh Clinical Palette
We move beyond "Safety Blue" into a sophisticated trio of Fresh Blue, Vibrant Green, and Soft Lila. These colors represent Trust, Growth, and Compassion, respectively.

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders to section content. Boundaries must be defined through:
1.  **Background Shifts:** Placing a `surface_container_lowest` card on a `surface_container_low` background.
2.  **Tonal Transitions:** Using subtle shifts between `surface_variant` and `surface`.

### Color Roles
- **Primary (`#00497d`):** Professional authority. Used for navigation and primary actions.
- **Secondary (`#1b6d24`):** Vitality and positive health indicators. Used for success states and "growth" metrics.
- **Tertiary (`#7b008f`):** The "Soft Lila" signature. Used for specialized medical categories, psychological health, or highlighting "eye-catching" anomalies.

### The "Glass & Gradient" Rule
To avoid a flat, "out-of-the-box" feel, use **Glassmorphism** for floating elements (e.g., patient quick-view modals). Use a `surface_container_lowest` color at 80% opacity with a `backdrop-blur` of 20px. 
*Signature Texture:* Apply a linear gradient from `primary` to `primary_container` for hero-level CTA buttons to provide a "jeweled" depth.

---

## 3. Typography: Editorial Authority
We pair the geometric aggression of **Space Grotesk** with the humanist clarity of **Manrope**.

- **The Display Scale (`display-lg` to `headline-sm`):** Uses *Space Grotesk*. This is our "llamativa" (eye-catching) element. Headings should feel bold, slightly tight in letter-spacing, and command the user's attention.
- **The Reading Scale (`title-lg` to `body-sm`):** Uses *Manrope*. This provides a clean, breathable experience for medical records and patient notes.

*Hierarchy Note:* In a medical context, the "Value" (e.g., Blood Pressure 120/80) should often use a `headline-lg` (Space Grotesk), while the "Label" uses a `label-md` (Manrope) in `on_surface_variant`.

---

## 4. Elevation & Depth: Atmospheric Layering
We do not "drop shadows" on everything. We "stack paper."

- **The Layering Principle:** 
    - Base Level: `background` (#f8f9fa).
    - Section Level: `surface_container_low`.
    - Content Card: `surface_container_lowest` (Pure White).
    - This creates a soft, natural lift that feels organic rather than digital.
- **Ambient Shadows:** For floating elements (Modals, Popovers), use a shadow with a 40px blur, 10px Y-offset, and 6% opacity using the `primary` color as the shadow tint. Avoid grey shadows.
- **The "Ghost Border" Fallback:** If a container sits on an identical color background, use the `outline_variant` token at **15% opacity**. It should be felt, not seen.

---

## 5. Components: Precision Elements

### Cards & Data Containers
- **Styling:** Forbid divider lines. Use `xl` (1.5rem) or `lg` (1rem) corner radius for cards.
- **Separation:** Use vertical white space from the spacing scale (e.g., 24px or 32px) to separate patient history items.

### Charts & Data Visualization (The Heart of the Dashboard)
- **Line Charts:** Use `primary` for the main trend line. Use a soft gradient fill beneath the line (from `primary` at 20% opacity to `surface` at 0%).
- **Bar Charts:** Use `secondary_fixed` for "healthy" ranges and `tertiary_fixed` for "needs attention" ranges. Corner radius on bars should be `sm` at the top.
- **Pie Charts:** Utilize the full palette (Blue, Green, Lila). Ensure high contrast between segments using `surface_container_lowest` as a 2px "gap" between slices.

### Buttons & Inputs
- **Primary Button:** Gradient of `primary` to `primary_container`, `full` (pill-shaped) roundedness, `title-sm` typography.
- **Input Fields:** `surface_container_high` background with no border. On focus, transition to a `ghost border` of `primary` at 40% and a soft `surface_tint` glow.

### Additional Signature Components
- **The "Vitality Chip":** A high-visibility chip using `secondary_container` for positive health statuses.
- **The "Pulse Tracker":** A micro-line chart placeholder integrated directly into a list item to show historical trends without opening a new page.

---

## 6. Do's and Don'ts

### Do:
- **Use "Space" as a separator.** If a layout feels cluttered, increase the padding, don't add a line.
- **Embrace Large Type.** Make the most important medical metric the largest thing on the screen.
- **Nesting Layers.** Use `surface_container_highest` for small "meta-data" boxes inside a `surface_container_lowest` card.

### Don't:
- **Don't use 100% Black.** Use `on_surface` (#191c1d) for text to maintain the "Fresh" aesthetic.
- **Don't use "Standard" Card Shadows.** Avoid the heavy, dark CSS defaults. If it looks like a 2014 material design app, it's too heavy.
- **Don't crowd the charts.** Charts need "breathing room" (at least 24px of internal padding) to remain readable and professional.

### Accessibility Note:
While we use soft lilas and fresh greens, ensure all "Actionable" text and "Error" states meet WCAG AA contrast ratios using the `on_error` and `on_primary` tokens against their respective containers.